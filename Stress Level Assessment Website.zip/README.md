
  # Stress Level Assessment Website

  This is a code bundle for Stress Level Assessment Website. The original project is available at https://www.figma.com/design/HSzB3ca3zakNvK6JV9aJjb/Stress-Level-Assessment-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  